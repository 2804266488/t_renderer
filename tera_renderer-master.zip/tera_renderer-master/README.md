# tera_renderer
Tera-based renderer for acados templated code

## build
Run:
```
cargo build --verbose --release
```

